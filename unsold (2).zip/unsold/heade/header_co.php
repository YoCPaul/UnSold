<?php session_start();?>


<meta charset="utf-8">
<link rel="stylesheet" href="navbar_style.css">
  <body>
  
    <!--header-->
    <header>
      <!--Barre de menu-->
    <nav class="navbar">
        <img src="../image/unsold_logo.png" id="logo">
      <div class="nav-links">
        <ul>
          <li><a href="Page_homme/index_homme.php">Homme</a></li>
          <li><a href="Page_femme/index_femme.php">Femme</a></li>
          <li><a href="Page_unisex/index_unisex.php">Unisex</a></li>
          <li><a href="Page_enfant/index_enfant.php">Enfant</a></li>
        </ul>
      </div>
      <!-- Menu hamurger Icone -->
      <img src="../image/HambMenu.png" alt="Menu" id="iconeMenuHamb">
      <div class="button">
        <li class="comptsurvol"><a href="#">
        <?php
        echo '<style>.nom-user {
                margin: 100px; /* Ajoute une marge de 10px à tous les côtés du paragraphe */
            }
        </style>
            <p class="nom-user">Bienvenue,<br>'. $_SESSION['utilisateur']. '!</p>';
        
        ?>
        <img src="../image/Icone_panier.png" alt="Panier" id="panier">
        </a>
          <ul class="dropdown-menu">
              <li><a href="../inscription/inscription.php">Modifier</a></li>
              <li><a href="../connexion/formulaire.php">Déconnexion</a></li>
              <li><a href="#">Commande</a></li>
              <li><a href="#">Historique d'achat</a></li>
          </ul>
        </li>
      </div>
      
    </nav>
    </header> 
  </body>
</html>