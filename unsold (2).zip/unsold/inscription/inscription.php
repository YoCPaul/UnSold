<?php require '../heade/header.php'; ?>
<link rel="stylesheet" href="../heade/navbar_style.css">
<link rel="stylesheet" href="../footer/footer_style.css">
<link rel="stylesheet" href="inscription.css"> 
<div class="inscrire">
<div class="liste_user">
    <div class="user-details">
        <center>
            <h1>Inscription</h1>
        </center>
        <form class="co" action="valide.php" method="POST">
            <div>
                <label for='nom'>Votre nom</label>
                <input type="text" id="nom" name="nom" placeholder="Nom" required>
            </div>
            <div>
                <label for="prenom">Votre Prénom</label>
                <input type="text" id="prenom" name="prenom" placeholder="Prénom" required>
            </div>
            <div>
                <label for="mail">Votre e-mail</label>
                <input type="email" id="mail" name="mail" placeholder="Mail" required>
            </div>
            <!--
            <div>
                <label for="adresse">Votre Adresse</label>
                <input type="text" id="adresse" name="adresse" placeholder="Adresse" required>
            </div>
-->
            <div>
                <label for="d_naissance">Votre Date de Naissance</label>
                <input type="date" id="d_naissance" name="d_naissance" placeholder="Date" required>
            </div>
            <div>
                <label for="mdp">Votre Mot de Passe</label>
                <input type="password" id="mdp" name="mdp" placeholder="Mot de passe" required>
            </div>
            <input type="submit" id='button' value="Inscription" name="ok">
        </form>   
    </div>
    <div class="user-details" style="text-align: center;">  </div>
</div>
<script src="../js/script.js"></script>

<?php require '../footer/footer.php'; ?>
