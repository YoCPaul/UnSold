<?php 
include("../inc/connexion.php");


$bdd->__construct();
if (isset($_POST['ok'])) {
    if(!empty($_POST['email'])AND !empty($_POST['prenom'])){
        $email = $_POST['email'];
        $mdp = $_POST['prenom'];

        $recupUser = $bdd->prepare('SELECT * FROM utilisateur WHERE mail = ? AND mdp = ?');
        $recupUser->execute(array($email, $mdp));
       // Vérifie si l'utilisateur existe dans la base de données
       if ($user = $recupUser->fetch()) {
        // Récupère le prénom de l'utilisateur depuis le résultat de la première requête
    $prenom = $user['prenom'];
    // Redirige l'utilisateur vers une autre page avec le nom d'utilisateur en tant que paramètre
    session_start();
    $_SESSION['utilisateur'] = $prenom;
    header("Location: http://localhost/unsold/index/index_co.php");
    exit;
}else{
    // Si l'utilisateur n'est pas connecté, redirige-le vers la page de connexion
    header("Location: http://localhost/unsold/inscription/inscription.php");
    exit;
}


}else{
echo "Veuillez renplire tout le champ...";
}
}

            



?>