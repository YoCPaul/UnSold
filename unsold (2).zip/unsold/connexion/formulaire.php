<?php require '../heade/header.php'; ?>

<link rel="stylesheet" href="../heade/navbar_style.css">
<link rel="stylesheet" href="../footer/footer_style.css">
<link rel="stylesheet" href="cssformu.css">
    <div class="connexion">
        <center>
            <br><h1>Connexion</h1>
        </center>
        <form class="co" action="co-reusie.php" method="POST">
            <div>
                <label for="email">Votre e-mail</label>
                <input type="email" id="email" name="email" placeholder="Mail" required>
            </div>
            <div>
                <label for="prenom">Votre Mot de Passe</label>
                <input type="text" id="prenom" name="prenom" placeholder="Mot de passe" required>
                <br>
                <br>
                
            </div>
            <input type="submit" id='button' value="Se Connecter" name='ok'>
        </form>
    </div>
<?php require '../footer/footer.php'; ?>