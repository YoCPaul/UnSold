<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mentions Legal</title>
</head>
<body>



<?php require '../heade/header.php'; ?>
<link rel="stylesheet" href="../heade/navbar_style.css">
<link rel="stylesheet" href="../footer/footer_style.css">
<link rel="stylesheet" href="mentionslegales.css"> 
<div style="border: none; box-shadow: 0 6px 3px rgba(0,0,0,.2); padding : 30px;"class="inscrire">
    <div class="liste_user">
        <div class="user-details">
            <center>
                <h1 style="color : #fff;">Mentions Légales</h1>
            </center>
            <form class="co" action="valide.php" method="POST">
                <div>
                   
    <p style="color : #fff;">
        <strong style="color: #886044; font-style: underline;">Éditeur du Site :</strong><br><br>
        UNSOLD<br>
        UnSoldShoe@gmail.com<br><br>

       <strong style="color: #886044;"> Finalité du Site :</strong><br><br>
        Le site a pour objectif de présenter un projet universitaire fictif de vente de chaussures. Aucune transaction financière n'est réellement effectuée, et les produits présentés sont fictifs.<br><br>

        <strong style="color: #886044;">Propriété Intellectuelle :</strong><br><br>
        L'ensemble du contenu du site, y compris les textes, images et vidéos, est protégé par le droit d'auteur. Toute reproduction ou utilisation non autorisée est interdite.<br><br>

        <strong style="color: #886044;">Collecte de Données Personnelles :</strong><br><br>
        Le site ne collecte aucune donnée personnelle de manière intentionnelle. Cependant, des cookies peuvent être utilisés à des fins statistiques et d'amélioration de l'expérience utilisateur. Consultez notre Politique de Confidentialité pour plus d'informations.<br><br>

        <strong style="color: #886044;">Liens Externes :</strong><br><br>
        Le site peut contenir des liens vers des sites tiers. Nous déclinons toute responsabilité quant au contenu de ces sites et aux éventuels dommages qui pourraient résulter de leur utilisation.<br><br>

        <strong style="color: #886044;">Responsabilité :</strong><br><br>
        Le projet universitaire décline toute responsabilité quant à l'exactitude des informations présentées sur le site. Les utilisateurs sont invités à vérifier les informations par d'autres moyens.<br><br>

        <strong style="color: #886044;">Droit Applicable et Juridiction Compétente :</strong><br><br>
        Les présentes mentions légales sont régies par le droit fictif. En cas de litige, la juridiction fictive est compétente.<br>
    </p>
            </form>   
        </div>
        <div class="user-details" style="text-align: center;">  </div>
    </div>
</div>
<script src="../js/script.js"></script>

<?php require '../footer/footer.php'; ?>

    
</body>
</html>